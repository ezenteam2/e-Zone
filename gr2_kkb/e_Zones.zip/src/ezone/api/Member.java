package ezone.api;

public class Member {
	private String memId;
	private String memPw;
	private String memName;
	private String memEmail;
	private String memNick;
	private String memPhone;
	private String memAddr;
	private String memCate;
	private String memProf;
	private java.sql.Date active;
	
	public Member() {
		super();
	}

	public String getMemId() {
		return memId;
	}

	public void setMemId(String memId) {
		this.memId = memId;
	}

	public String getMemPw() {
		return memPw;
	}

	public void setMemPw(String memPw) {
		this.memPw = memPw;
	}

	public String getMemName() {
		return memName;
	}

	public void setMemName(String memName) {
		this.memName = memName;
	}

	public String getMemEmail() {
		return memEmail;
	}

	public void setMemEmail(String memEmail) {
		this.memEmail = memEmail;
	}

	public String getMemNick() {
		return memNick;
	}

	public void setMemNick(String memNick) {
		this.memNick = memNick;
	}

	public String getMemPhone() {
		return memPhone;
	}

	public void setMemPhone(String memPhone) {
		this.memPhone = memPhone;
	}

	public String getMemAddr() {
		return memAddr;
	}

	public void setMemAddr(String memAddr) {
		this.memAddr = memAddr;
	}

	public String getMemCate() {
		return memCate;
	}

	public void setMemCate(String memCate) {
		this.memCate = memCate;
	}

	public String getMemProf() {
		return memProf;
	}

	public void setMemProf(String memProf) {
		this.memProf = memProf;
	}

	public java.sql.Date getActive() {
		return active;
	}

	public void setActive(java.sql.Date active) {
		this.active = active;
	}

	
	
	
}
