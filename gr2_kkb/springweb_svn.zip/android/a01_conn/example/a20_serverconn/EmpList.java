package com.example.a20_serverconn;

import java.util.ArrayList;

public class EmpList {
    private ArrayList<Emp> emplist;
    public ArrayList<Emp> getEmplist() {
        return emplist;
    }
    public void setEmplist(ArrayList<Emp> emplist) {
        this.emplist = emplist;
    }
}
