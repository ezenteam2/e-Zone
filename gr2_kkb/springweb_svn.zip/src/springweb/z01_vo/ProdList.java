package springweb.z01_vo;

import java.util.ArrayList;

public class ProdList {
	private ArrayList<Product> plist;

	public ArrayList<Product> getPlist() {
		return plist;
	}

	public void setPlist(ArrayList<Product> plist) {
		this.plist = plist;
	}
	
}
