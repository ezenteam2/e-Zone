package springweb.a01_basic;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class A02_ExpCtrl {
	@RequestMapping("exp02.do")
	public String start(@RequestParam("num01") int num01, @RequestParam("num02") int num02, Model d) {
		d.addAttribute("total", num01+num02);
		return "WEB-INF\\views\\a01_basic\\a03_exp.jsp";
	}
}
