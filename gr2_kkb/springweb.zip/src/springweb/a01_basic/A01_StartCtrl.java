package springweb.a01_basic;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class A01_StartCtrl {
	/*
	 # controller 사용.
	 1. 선언.
	 2. @ controller
	 3. 메서드별로 요청 url를 선언. 
	 4. 연결되는 view단 선언...
	 5. container에 등록...
	 */
	
	@RequestMapping("/start.do")
	public String start() {
		return "WEB-INF\\views\\a01_basic\\a01_basic.jsp";
	}	
	@RequestMapping("/start2.do")
	public String start2(@RequestParam("name") String name, Model d) {
		System.out.println("요청값 : " + name);
		
		d.addAttribute("md01", name+"님 안녕하세요");
		return "WEB-INF\\views\\a01_basic\\a02_show.jsp";
	}
	
}
