package jspexp.b01_database;

import java.sql.*;
import java.util.ArrayList;
import jspexp.z01_vo.DEPT;
import jspexp.z01_vo.P4MEMBER;

public class A02_DEPT {

	private Connection con;
	private Statement stmt;
	private ResultSet rs;
		
	public void setCon() throws SQLException{
		

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String info = "jdbc:oracle:thin:@192.168.4.90:1521:xe";
		con = DriverManager.getConnection(info, "scott", "tiger");


	}
	
	
	public ArrayList<DEPT> getDeptList(){
		ArrayList<DEPT> deptList = new ArrayList<DEPT>();
		
		try {
			setCon();
			
			String sql = "SELECT * FROM dept11 ORDER BY DEPTNO";
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			
			DEPT dept = null;
			while(rs.next()) {
				dept = new DEPT();
				dept.setDeptno(rs.getInt("deptno"));
				dept.setDname(rs.getString("dname"));
				dept.setLoc(rs.getString("loc"));
				deptList.add(dept);
			}
			
			rs.close();
			stmt.close();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return deptList;
	}

	
	
	public void insertDept(DEPT ins) {
		
		try {
			setCon();
			
			String sql = "INSERT INTO dept11 VALUES (dept11_seq.nextval, '"	+ ins.getDname() + "', '" + ins.getLoc() + "')";
			System.out.println(sql);
			con.setAutoCommit(false);
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			con.commit();
			
			stmt.close();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
