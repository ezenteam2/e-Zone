package jspexp.z02_mvcExp;

import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import jspexp.z01_vo.Product;
import z00_util.Nk;

public class expProductService {
	
	private expProductDAO dao;

	public expProductService() {
		super();
		dao = new expProductDAO();
	}
	
	public ArrayList<Product> getProductList(Product sch){
		return dao.proList(sch);
	}

}
