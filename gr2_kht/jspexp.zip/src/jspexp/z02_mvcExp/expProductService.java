package jspexp.z02_mvcExp;

import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import jspexp.z01_vo.Product;
import z00_util.Nk;

public class expProductService {
	
	private expProductDAO dao;

	public expProductService() {
		super();
		dao = new expProductDAO();
	}
	
	public ArrayList<Product> getProductList(Product sch){
		return dao.proList(sch);
	}
	
/*	
	public ArrayList<Product> elist(HttpServletRequest req){
		
		int sno = Nk.toInt(req.getParameter("sno"));
		String kind  = Nk.toStr(req.getParameter("kind"));
		String img = Nk.toStr(req.getParameter("img"));
		String name = Nk.toStr(req.getParameter("name"));
		int price = Nk.toInt(req.getParameter("price"));
		int cnt = Nk.toInt(req.getParameter("cnt"));
		Date regDate = req.getParameter("regDate");
		Date uptDate = req.getParameter("uptDate");
		String notice = Nk.toStr(req.getParameter("notice"));
		
		return dao.getProductList(new Product(sno, kind, img, name, price, cnt, regDate, uptDate, notice));
	}
*/

	
}
