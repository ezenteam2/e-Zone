package jspexp.z02_mvcExp;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspexp.z01_vo.Product;

/**
 * Servlet implementation class expUserCtrl
 */
@WebServlet("/expUserCtrl")
public class expUserCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private expUserListService service;
	private expUserProDetailService serviceDet;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public expUserCtrl() {
        super();
        // TODO Auto-generated constructor stub
        service = new expUserListService();
        serviceDet = new expUserProDetailService();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		
		String proc = request.getParameter("proc");
		if(proc==null||proc.contentEquals("")) proc="main";
		
		if(proc.equals("main")) {
			request.setAttribute("plist", service.getProductList(new Product()));
		}
		
		if(proc.equals("detail")) {
			request.setAttribute("prod", serviceDet.detailPro(request));;
		}
		
		if(proc.equals("cart")) {
			HttpSession session = request.getSession();

			ArrayList<Product> clist = null;
			
			if(session.getAttribute("cart")==null) {
				clist = new ArrayList<Product>();

			} else {
				clist = (ArrayList<Product>)session.getAttribute("cart");				
			}
			
			Product p01 = serviceDet.detailPro(request);
			p01.setCnt(1);
			clist.add(serviceDet.detailPro(request));
			session.setAttribute("cart", clist);
		}
		

		
		String page = "z02_mvcExp\\us_pro_list.jsp";
		
		if(proc.equals("detail")||proc.equals("cart")) page="z02_mvcExp\\us_pro_detail.jsp";
		if(proc.equals("cartList")) page = "a11\\us_cart_list.jsp";
		
		RequestDispatcher rd = request.getRequestDispatcher(page);
		rd.forward(request, response);
	}

}
