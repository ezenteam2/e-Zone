package jspexp.z02_mvcExp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jspexp.z01_vo.Product;

public class expProDetDAO {
	
	private Connection con;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public void setCon() throws SQLException{
		
	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		String info = "jdbc:oracle:thin:@localhost:1521:xe";
		con = DriverManager.getConnection(info, "scott", "tiger");
	
	}
	
	public Product detailPro(int sno) {
		
		Product pro = null;
		
		try {
			setCon();
			
			String sql = "SELECT * FROM MVCPRODUCT WHERE sno = ? ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, sno);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				pro = new Product(
						rs.getInt(1),
						rs.getString(2),
						rs.getString(6),
						rs.getString(3),
						rs.getInt(4),
						rs.getInt(5),
						rs.getDate(7),
						rs.getDate(8),
						rs.getString(9)
						);
			}
			
			rs.close();
			pstmt.close();
			con.close();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return pro;		
	}

}
