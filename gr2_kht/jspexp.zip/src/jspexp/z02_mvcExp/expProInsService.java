package jspexp.z02_mvcExp;

import javax.servlet.http.HttpServletRequest;

import jspexp.z01_vo.Product;
import z00_util.Nk;

public class expProInsService {
	
	private expProInsDAO dao;

	public expProInsService() {
		super();
		dao = new expProInsDAO();
	}
	
	public void insProList(HttpServletRequest req) {
		
		String kind = Nk.toStr(req.getParameter("kind"));
		String name = Nk.toStr(req.getParameter("name"));
		int price = Nk.toInt(req.getParameter("price"));
		int cnt = Nk.toInt(req.getParameter("cnt"));
		String img = Nk.toStr(req.getParameter("img"));
		String notice = Nk.toStr(req.getParameter("notice"));
		
		dao.insProList(new Product(kind, name, price, cnt, img, notice));
	}

}
