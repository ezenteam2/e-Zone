package jspexp.z02_mvcExp;

import javax.servlet.http.HttpServletRequest;

import jspexp.z01_vo.Product;
import z00_util.Nk;

public class expProUptService {
	
	private expProUptDAO dao;

	public expProUptService() {
		super();
		dao = new expProUptDAO();
	}
	
	public void uptPro(HttpServletRequest req) {
		
		String kind = Nk.toStr(req.getParameter("kind"));
		String name = Nk.toStr(req.getParameter("name"));
		int price = Nk.toInt(req.getParameter("price"));
		int cnt = Nk.toInt(req.getParameter("cnt"));
		String img = Nk.toStr(req.getParameter("img"));
		String notice = Nk.toStr(req.getParameter("notice"));
		
		dao.uptProList(new Product(kind, name, price, cnt, img, notice));
	}
	
}
