package jspexp.z02_mvcExp;

import javax.servlet.http.HttpServletRequest;

import jspexp.z01_vo.Product;
import z00_util.Nk;

public class expProUptService {
	
	private expProUptDAO dao;

	public expProUptService() {
		super();
		dao = new expProUptDAO();
	}
	
	public void uptPro(HttpServletRequest req) {
		
		String kind = Nk.toStr(req.getParameter("kind"));
		System.out.println("kind:"+kind);
		String name = Nk.toStr(req.getParameter("name"));
		System.out.println("name:"+name);
		int price = Nk.toInt(req.getParameter("price"));
		System.out.println("price:"+price);
		int cnt = Nk.toInt(req.getParameter("cnt"));
		System.out.println("cnt:"+cnt);
		String img = Nk.toStr(req.getParameter("img"));
		String notice = Nk.toStr(req.getParameter("notice"));
		int sno = Nk.toInt(req.getParameter("sno"));
		
		dao.uptProList(new Product(kind, name, price, cnt, img, notice, sno));
	}
	
}
