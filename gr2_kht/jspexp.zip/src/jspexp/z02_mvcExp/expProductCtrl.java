package jspexp.z02_mvcExp;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jspexp.z01_vo.Product;

/**
 * Servlet implementation class expProductCtrl
 */
@WebServlet("/expProductCtrl")
public class expProductCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private expProductService service;
	private expProInsService serviceIns;
	private expProDetService serviceDet;
	private expProUptService serviceUpt;
	private expProDeleteService serviceDelete;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public expProductCtrl() {
        super();
        // TODO Auto-generated constructor stub
        service = new expProductService();
        serviceIns = new expProInsService();
        serviceDet = new expProDetService();
        serviceUpt = new expProUptService();
        serviceDelete = new expProDeleteService();
    
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		
		String proc = request.getParameter("proc");
		if(proc==null||proc.equals("")) proc="main";

		
		if(proc.equals("main")) {
			request.setAttribute("plist", service.getProductList(new Product()));			
		}

		
		if(proc.equals("ins")) {
			serviceIns.insProList(request);
		}
		
		if(proc.equals("detail")) {
			request.setAttribute("pro", serviceDet.detailPro(request));
		}
		
		if(proc.equals("update")) {
			serviceUpt.uptPro(request);
		}
		
		if(proc.equals("delete")) {
			serviceDelete.deletePro(request);
		}

		
		String page="z02_mvcExp\\ad_pro_list.jsp";
		
		if(proc.equals("insForm")||proc.equals("ins")) page="z02_mvcExp\\ad_pro_insert.jsp";
		if(proc.equals("detail")||proc.equals("update")||proc.equals("delete")) page="z02_mvcExp\\ad_pro_detail.jsp";
		
		RequestDispatcher rd = request.getRequestDispatcher(page);
		rd.forward(request, response);
	
	}

}
