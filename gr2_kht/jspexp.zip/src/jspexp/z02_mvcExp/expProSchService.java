package jspexp.z02_mvcExp;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import jspexp.z01_vo.Product;
import z00_util.Nk;

public class expProSchService {
	
	private expProSchDAO dao;

	public expProSchService() {
		super();
		dao = new expProSchDAO();
	}
	
	public ArrayList<Product> schProList(HttpServletRequest request){

		int frPrice = Nk.toInt(request.getParameter("frPrice"));
		int toPrice = Nk.toInt(request.getParameter("toPrice"));
		String name = Nk.toStr(request.getParameter("name"));

		System.out.println("frPirce:"+frPrice);
		System.out.println("toPirce:"+toPrice);
		System.out.println("name:"+name);
		return dao.schProList(new Product(frPrice, toPrice, name));
	}

}
