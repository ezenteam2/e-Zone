package jspexp.z02_mvcExp;

import javax.servlet.http.HttpServletRequest;

import z00_util.Nk;

public class expProDeleteService {

	private expProDeleteDAO dao;

	public expProDeleteService() {
		super();
		dao = new expProDeleteDAO();
	}
	
	public void deletePro(HttpServletRequest req) {
		dao.deleteProList(Nk.toInt(req.getParameter("sno")));
	}
	
}
