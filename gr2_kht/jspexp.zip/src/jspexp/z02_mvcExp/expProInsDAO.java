package jspexp.z02_mvcExp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jspexp.z01_vo.Product;

public class expProInsDAO {

	private Connection con;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public void setCon() throws SQLException{
		
	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		String info = "jdbc:oracle:thin:@localhost:1521:xe";
		con = DriverManager.getConnection(info, "scott", "tiger");
	
	}
	
	public void insProList(Product ins) {
		
		try {
			setCon();
			
			String sql = "INSERT INTO MVCPRODUCT VALUES (mvc_pro_sno_seq.nextval, ?, ?, ?, ?, ?, sysdate, sysdate, ?)";
			System.out.println(sql);
			
			con.setAutoCommit(false);
			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, ins.getKind());
			pstmt.setString(2, ins.getName());
			pstmt.setInt(3, ins.getPrice());
			pstmt.setInt(4, ins.getCnt());
			pstmt.setString(5, ins.getImg());
			pstmt.setString(6, ins.getNotice());
			
			pstmt.executeUpdate();
			con.commit();
			
			System.out.println("등록 성공");
			
			pstmt.close();
			con.close();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	
	
}
