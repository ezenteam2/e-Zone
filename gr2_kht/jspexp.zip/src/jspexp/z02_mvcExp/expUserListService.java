package jspexp.z02_mvcExp;

import java.util.ArrayList;

import jspexp.z01_vo.Product;

public class expUserListService {
	
	private expProductDAO dao;

	public expUserListService() {
		super();
		dao = new expProductDAO();
	}
	
	public ArrayList<Product> getProductList(Product sch){
		return dao.proList(sch);
	}

}
