package jspexp.z02_mvcExp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jspexp.z01_vo.Product;

public class expProUptDAO {

	private Connection con;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public void setCon() throws SQLException{
		
	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		String info = "jdbc:oracle:thin:@localhost:1521:ORCL";
		con = DriverManager.getConnection(info, "scott", "tiger");
	
	}
	
	public void uptProList(Product upt) {

		
		
		try {
			setCon();
			
			String sql = "UPDATE MVCPRODUCT \r\n" + 
					"SET kind = ?, name = ?, price = ?, cnt = ?, img = ?, uptDate = sysdate, notice = ? \r\n" + 
					"WHERE sno= ?";
			
			con.setAutoCommit(false);
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, upt.getKind());
			pstmt.setString(2, upt.getName());
			pstmt.setInt(3, upt.getPrice());
			pstmt.setInt(4, upt.getCnt());
			pstmt.setString(5, upt.getImg());
			pstmt.setString(6, upt.getNotice());
			pstmt.setInt(7, upt.getSno());
			
			System.out.println(sql);
			
			pstmt.executeUpdate();
			con.commit();
			
			pstmt.close();
			con.close();
			System.out.println("수정 완료");
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	
}
