package jspexp.z02_mvcExp;

import javax.servlet.http.HttpServletRequest;

import jspexp.z01_vo.Product;
import z00_util.Nk;

public class expProDetService {
	
	private expProDetDAO dao;
	
	public expProDetService() {
		super();
		dao = new expProDetDAO();
	}



	public Product detailPro(HttpServletRequest req) {
		return dao.detailPro(Nk.toInt(req.getParameter("sno")));
	}

}
