package jspexp.c01_mvc;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspexp.z01_vo.P4MEMBER;

/**
 * Servlet implementation class A03_MemberCtrl
 */
@WebServlet(name = "memlog", urlPatterns = { "/memlog" })
public class A03_MemberCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private A03_MemberService service;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public A03_MemberCtrl() {
        super();
        // TODO Auto-generated constructor stub
        service = new A03_MemberService();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");

		String proc = request.getParameter("proc");
		if (proc==null) proc="";
		// 1. 요청값 받기
		
		
		if(proc.equals("login")) {
			P4MEMBER mem = service.login(request);
			if(mem!=null) {
				// DB를 확인하여 P4MEMBER 객체가 있을 때, SESSION 처리
				HttpSession session = request.getSession();
				session.setAttribute("mem", mem);
				// SESSION 입력 처리 완료				
			}
		}
		// 2. 모델
		
		if(proc!=null&&proc.equals("logout")) {
			// logout 클릭시 session값을 비활성화
			request.getSession().invalidate();
			
		}
		
		String page = "a11_mvc\\a03_login.jsp";
		if(proc.equals("main")) {
			page = "a11_mvc\\a03_main.jsp";
			
		}
		RequestDispatcher rd = request.getRequestDispatcher(page);
		rd.forward(request,response);
		
//		if(proc.equals("login")) {
	//		request.setAttribute("memlog", service.e);
		//}
	}

}
