package jspexp.c01_mvc;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspexp.b01_database.A01_Database;
import jspexp.z01_vo.Emp;

/**
 * Servlet implementation class empLoginCtrl
 */
@WebServlet(name = "empLogin", urlPatterns = { "/empLogin" })
public class empLoginCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private empLoginService service;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public empLoginCtrl() {
        super();
        // TODO Auto-generated constructor stub
        service = new empLoginService();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		
		String proc = request.getParameter("proc");
		if (proc==null) proc="";
		
		
		if(proc.equals("login")) {
			Emp mem =service.login(request);
			if(mem!=null) {
				HttpSession session = request.getSession();
				session.setAttribute("mem", mem);
			}
		}
		
		
		if(proc!=null&&proc.equals("logout")) {
			request.getSession().invalidate();
		}
		
		String page = "a11_mvc\\empLogin.jsp";
		if(proc.equals("main")) {
			page="a11_mvc\\a02_empList.jsp";
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(page);
		rd.forward(request, response);
		
	}

}
