package jspexp.c01_mvc;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jspexp.b01_database.A01_Database;

/**
 * Servlet implementation class empLoginCtrl
 */
@WebServlet(name = "empLogin", urlPatterns = { "/empLogin" })
public class empLoginCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private empLoginService service;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public empLoginCtrl() {
        super();
        // TODO Auto-generated constructor stub
        service = new empLoginService();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		
		String proc = request.getParameter("proc");
		if (proc==null) proc="";
		
		
		if(proc.equals("login")) {
			A01_Database mem =service.login(request);
		}
		
		
		
		
		
		
	}

}
