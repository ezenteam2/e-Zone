package jspexp.c01_mvc;

import jspexp.b01_database.A02_P4MEMBER;
import jspexp.z01_vo.P4MEMBER;

import javax.servlet.http.HttpServletRequest;

public class A03_MemberService {
	
	private A02_P4MEMBER dao;

	public A03_MemberService() {
		super();
		dao = new A02_P4MEMBER();
	}
	
	public P4MEMBER login(HttpServletRequest request){
		String id = request.getParameter("id");
		if(id==null) id="";
		String pw = request.getParameter("pw");
		if(pw==null) pw="";
		
		return dao.login(new P4MEMBER(id, pw));
	}

}
