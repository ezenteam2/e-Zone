package jspexp.c01_mvc;

import jspexp.b01_database.*;

public class A04_MemberRegService {

	private A02_P4MEMBER dao;

	public A04_MemberRegService() {
		super();
		dao = new A02_P4MEMBER();
	}
	
	public boolean checkReg(String mem_id) {
		return dao.memberCk(mem_id);
	}
	
	
}
