package jspexp.c01_mvc;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class A04_MemberRegService
 */
@WebServlet(name = "registP4", urlPatterns = { "/registP4" })
public class A04_MemberRegCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private A04_MemberRegService service;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public A04_MemberRegCtrl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String id = request.getParameter("id");
		
		if(id!=null&&!id.equals("")) {
			// id 중복 여부를 service에서 확인
			request.setAttribute("isMember", service.checkReg(id));
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("a11_mvc\\a04_regCheck.jsp");
		rd.forward(request, response);
	}

}
