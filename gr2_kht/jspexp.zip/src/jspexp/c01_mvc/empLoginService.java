package jspexp.c01_mvc;

import javax.servlet.http.HttpServletRequest;

import jspexp.b01_database.A01_Database;
import jspexp.z01_vo.Emp;


public class empLoginService {
	
	private A01_Database dao;

	public empLoginService() {
		super();
		dao = new A01_Database();
	}
	
	public Emp login(HttpServletRequest request) {
		String empnoS = request.getParameter("empno");
		if(empno==null) empnoS="";
		String enameS = request.getParameter("ename")
		if(ename==null) enameS="";
		
		
		return dao.login(new Emp(empno, ename));
	}

}
