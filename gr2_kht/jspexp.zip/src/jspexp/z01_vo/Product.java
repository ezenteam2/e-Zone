package jspexp.z01_vo;

import java.util.Date;

// jspexp.z01_vo.Product
// sno kind name price cnt
public class Product {
	
	private int sno;
	private String kind;
	private String name;
	private int price;
	private int frPrice;
	private int toPrice;
	private int cnt;
	private String img;
	private Date regDate;
	private Date uptDate;
	private String notice;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Product(int sno, String kind, String name, int price, int cnt) {
		super();
		this.sno = sno;
		this.kind = kind;
		this.name = name;
		this.price = price;
		this.cnt = cnt;
	}

	public Product(String kind, String name, int price, int cnt) {
		super();
		this.kind = kind;
		this.name = name;
		this.price = price;
		this.cnt = cnt;
	}
	
	
	
	public Product(int frPrice, int toPrice, String name) {
		super();
		this.name = name;
		this.frPrice = frPrice;
		this.toPrice = toPrice;
	}		// 검색을 위한 생성자

	
	
	public Product(String name, int price, int cnt) {
		super();
		this.name = name;
		this.price = price;
		this.cnt = cnt;
	}


	
	
	
	public Product(int sno, String kind, String name, int price, int frPrice, int toPrice, int cnt, String img,
			Date regDate, Date uptDate, String notice) {
		super();
		this.sno = sno;
		this.kind = kind;
		this.name = name;
		this.price = price;
		this.frPrice = frPrice;
		this.toPrice = toPrice;
		this.cnt = cnt;
		this.img = img;
		this.regDate = regDate;
		this.uptDate = uptDate;
		this.notice = notice;
	}
	
	


	public Product(int sno, String kind, String img, String name, int price, int cnt, Date regDate, Date uptDate,
			String notice) {
		super();
		this.sno = sno;
		this.kind = kind;
		this.img = img;
		this.name = name;
		this.price = price;
		this.cnt = cnt;
		this.regDate = regDate;
		this.uptDate = uptDate;
		this.notice = notice;
	}
	
	


	public Product(String kind, String name, int price, int cnt, String img, String notice) {
		super();
		this.kind = kind;
		this.name = name;
		this.price = price;
		this.cnt = cnt;
		this.img = img;
		this.notice = notice;
	}


	public Product(String kind, String name, int price, int cnt, String img, String notice, int sno) {
		super();
		this.kind = kind;
		this.name = name;
		this.price = price;
		this.cnt = cnt;
		this.img = img;
		this.notice = notice;
		this.sno = sno;
	}
	
	
	public int getSno() {
		return sno;
	}


	public void setSno(int sno) {
		this.sno = sno;
	}


	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}


	public int getFrPrice() {
		return frPrice;
	}


	public void setFrPrice(int frPrice) {
		this.frPrice = frPrice;
	}


	public int getToPrice() {
		return toPrice;
	}


	public void setToPrice(int toPrice) {
		this.toPrice = toPrice;
	}


	public String getImg() {
		return img;
	}


	public void setImg(String img) {
		this.img = img;
	}


	public Date getRegDate() {
		return regDate;
	}


	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}


	public Date getUptDate() {
		return uptDate;
	}


	public void setUptDate(Date uptDate) {
		this.uptDate = uptDate;
	}


	public String getNotice() {
		return notice;
	}


	public void setNotice(String notice) {
		this.notice = notice;
	}

	
	
	
	
	
}
