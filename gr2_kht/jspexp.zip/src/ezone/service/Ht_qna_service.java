package ezone.service;

import java.util.ArrayList;

import ezone.dao.Ht_qna_dao;
import ezone.vo.Ht_qna_VO;

public class Ht_qna_service {
	
	private Ht_qna_dao dao;

	public Ht_qna_service() {
		super();
		dao = new Ht_qna_dao();
	}
	
	public ArrayList<Ht_qna_VO> getqnaList(Ht_qna_VO sch){
		return dao.qnaList(sch);
	}

}
