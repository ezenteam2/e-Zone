package ezone.service;

import java.util.ArrayList;

import ezone.dao.Ht_faq_dao;
import ezone.vo.Ht_faq_VO;

public class Ht_faq_service {
	
	private Ht_faq_dao dao;

	public Ht_faq_service() {
		super();
		dao = new Ht_faq_dao();
	}
	
	public ArrayList<Ht_faq_VO> getFaqList(Ht_faq_VO sch){
		return dao.faqList(sch);
	}

}
