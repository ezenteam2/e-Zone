package ezone.vo;

public class Ht_qna_VO {

}
