package ezone.dao;

public class Ht_qna_dao {

}
